const express = require('express');
const cors=require('cors')
const bodyParser = require('body-parser');
const fs = require('fs').promises;
const util = require('util');
const readFileAsync = util.promisify(fs.readFile);
const uuid = require('uuid');
const axios = require('axios');


const app = express();
const port = 3001; // You can use any port you prefer

app.use(bodyParser.json());

const dataFilePath = '/data.json';

app.use(cors(
    {
        origin: ["http://localhost:4200"],
        methods: ["POST", "GET", "PUT","DELETE"],
        credentials: true
    }
));

app.get('/tasks', async (req, res) => {
  apiUrl='https://jsonplaceholder.typicode.com/posts';

  try {
    const response = await axios.get('https://jsonplaceholder.typicode.com/posts');
    const data = response.data;

    // Do something with the data here
    // You can send it back as a response or process it further
    console.log("data",data);
    res.status(200).json(data);
  } catch (error) {
    console.error('Error fetching data:', error);
    res.status(500).json({ error: 'Failed to fetch data' });
  }

  });

  app.get('/users', async (req, res) => {
    try {
      const data = await fs.readFile('data.json', 'utf8');
      const jsonData = JSON.parse(data);
      res.json(jsonData.Users); // Send the 'Users' array as the response
    } catch (error) {
      console.error('Error reading data file:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  app.post('/tasks', async (req, res) => {

  
    // try {
    //   const data = await fs.readFile('data.json', 'utf8');
    //   const jsonData = JSON.parse(data);
  
    //   const newTask = req.body;
    //   newTask.id = uuid.v4(); // Generate a unique ID for the task using uuid
    //   jsonData.Tasks.push(newTask);
  
    //   await fs.writeFile('data.json', JSON.stringify(jsonData, null, 2));
  
    //   res.json({ message: 'Task added successfully' });
    // } catch (error) {
    //   console.error('Error adding task:', error);
    //   res.status(500).json({ error: 'Internal server error' });
    // }
  });

  app.delete('/tasks/:taskId', async (req, res) => {
    try {
      const taskId = req.params.taskId;
      const data = await fs.readFile('data.json', 'utf8');
      const jsonData = JSON.parse(data);
  
      // Remove the task with the specified ID from the array
      jsonData.Tasks = jsonData.Tasks.filter(task => task.id !== taskId);
  
      await fs.writeFile('data.json', JSON.stringify(jsonData, null, 2));
  
      res.json({ message: 'Task deleted successfully' });
    } catch (error) {
      console.error('Error deleting task:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });
  
  


app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
