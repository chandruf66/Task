import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class TaskService {
  private baseUrl = 'http://localhost:3001';

  constructor(private http: HttpClient) {}

  getUsers(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/users`);
  }

  addTask(taskData: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/tasks`, taskData);
  }

  getTasks(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/tasks`);
  }

  deleteTask(taskId: number): Observable<any> {
    return this.http.delete<any>(`${this.baseUrl}/tasks/${taskId}`);
  }
  
}
