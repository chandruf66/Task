import { Component, OnInit } from '@angular/core';
import { TaskService } from '../task.service';

@Component({
  selector: 'app-task-list',
  templateUrl: './task-list.component.html',
  styleUrls: ['./task-list.component.css']
})
export class TaskListComponent implements OnInit {
 // tasks: any[] = [];
  users: any[] = []; // Define an array to store users
  tasks: any[] = []; // Your tasks array
  currentPage: number = 1; // Current page number
  itemsPerPage: number = 10; // Number of items to display per page
  searchTerm: string = ''; // Search term
  filteredTasks: any[] = []; // Filtered tasks array

  constructor(private taskService: TaskService) {}

  ngOnInit(): void {
    this.taskService.getTasks().subscribe(tasks => {
      this.tasks = tasks;
    });

    this.taskService.getUsers().subscribe(users => {
      this.users = users;
    });
  }

 

  // Implement a function to change the current page
  changePage(newPage: number) {
    this.currentPage = newPage;
  }

  // Define the getUserName function
  getUserName(userId: number): string {
    const user = this.users.find(user => user.id == userId);
    return user ? user.name : 'Unknown';
  }

 
  filterTasks() {
   
    this.filteredTasks = this.tasks.filter(task =>
      task.title.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      task.body.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
    console.log("coming",this.filteredTasks);
    this.currentPage = 1; // Reset to the first page when filtering
  }
  getPages(): number[] {
    const totalPages = Math.ceil(this.filteredTasks.length / this.itemsPerPage);
    return Array(totalPages).fill(0).map((_, index) => index + 1);
  }
  

  // Define the onDelete method
  onDelete(taskId: number) {
    this.taskService.deleteTask(taskId).subscribe(
      () => {
        console.log(`Deleted task with ID: ${taskId}`);
        // Refresh the task list after deletion
        this.tasks = this.tasks.filter(task => task.id !== taskId);
      },
      error => {
        console.error(`Error deleting task with ID: ${taskId}`, error);
      }
    );
  }
  
}
