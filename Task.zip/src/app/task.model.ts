export interface TaskResponse {
    Users: any[]; // Adjust the type as per your user structure
    Task: any[]; // Adjust the type as per your task structure
  }
  