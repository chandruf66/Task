import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TaskService } from '../task.service';

@Component({
  selector: 'app-task-form',
  templateUrl: './task-form.component.html',
  styleUrls: ['./task-form.component.css']
})
export class TaskFormComponent implements OnInit {
  taskForm: FormGroup;
  users: any[] = [];

  constructor(private formBuilder: FormBuilder, private taskService: TaskService) {
    this.taskForm = this.formBuilder.group({
      Task: ['', [Validators.required, Validators.maxLength(200)]],
      Expiry_date: [''],
      User: [''],
      important: [false]
    });
  }

  ngOnInit(): void {
    this.taskService.getUsers().subscribe(users => {
      this.users = users;
    });
  }

  submitForm() {
    if (this.taskForm.valid) {
      const formData = this.taskForm.value;
      formData.Created_on = new Date().toLocaleDateString(); 
      this.taskService.addTask(formData).subscribe(response => {
        console.log('Task added:', response);
        this.taskForm.reset();
      });
    }
  }
}
